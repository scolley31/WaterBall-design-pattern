package org.example;

public class Telecom {

    public Telecom() {
    }


    public void connect() {
        System.out.println("通訊設備連結");
    }

    public void disconnect() {
        System.out.println("通訊設備關閉");
    }


}
