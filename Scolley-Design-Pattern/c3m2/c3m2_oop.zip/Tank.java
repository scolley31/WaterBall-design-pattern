package org.example;

public class Tank {
    public Tank() {
    }

    public void moveForward() {
        System.out.println("坦克向前移動");
    }

    public void moveBackward() {
        System.out.println("坦克向後移動");
    }
}
