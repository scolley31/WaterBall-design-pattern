package org.example;

public class Button {

    private Lowercase lowercase;

    public Button(Lowercase lowercase) {
        this.lowercase = lowercase;
    }

    public Lowercase getLowercase() {
        return lowercase;
    }
}
