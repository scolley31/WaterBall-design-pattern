package org.example;

public interface CommandLine {
    int inputIntByUser();
}
