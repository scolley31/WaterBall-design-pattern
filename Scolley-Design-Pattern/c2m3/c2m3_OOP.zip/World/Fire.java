package org.example.World;

public class Fire extends Sprite {
    public Fire() {
        name = "F";
    }
}
