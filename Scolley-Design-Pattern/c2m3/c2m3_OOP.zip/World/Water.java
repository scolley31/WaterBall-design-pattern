package org.example.World;

public class Water extends Sprite{
    public Water() {
        name = "W";
    }
}
